package com.example.demo.config;

import com.example.demo.security.JwtAuthenticationFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(
            AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/auth/**", "/register", "/error").permitAll()

                        // Создание лицензии ADMIN
                        .requestMatchers(HttpMethod.POST, "/api/licenses/create").hasAuthority("ADMIN")
                        // Активация, проверка, продление утентифицированный
                        .requestMatchers("/api/licenses/activate", "/api/licenses/check", "/api/licenses/renew")
                        .authenticated()
                        // GET к лицензиям
                        .requestMatchers(HttpMethod.GET, "/api/licenses/**").hasAnyAuthority("USER", "ADMIN")

                        // GET к сигнатурам
                        .requestMatchers(HttpMethod.GET, "/api/signatures/**").hasAnyAuthority("USER", "ADMIN")
                        // Создание, обновление, удаление ADMIN
                        .requestMatchers(HttpMethod.POST, "/api/signatures").hasAuthority("ADMIN")
                        .requestMatchers(HttpMethod.PUT, "/api/signatures/*").hasAuthority("ADMIN")
                        .requestMatchers(HttpMethod.DELETE, "/api/signatures/*").hasAuthority("ADMIN")
                        // История и аудит ADMIN
                        .requestMatchers("/api/signatures/*/history", "/api/signatures/*/audit").hasAuthority("ADMIN")

                        .anyRequest().authenticated()
                )
                .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class)
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }
}