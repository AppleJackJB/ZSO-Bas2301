package com.example.demo.service;

import com.example.demo.dto.license.Ticket;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.security.PrivateKey;
import java.security.Signature;
import java.util.Base64;

@Service
@RequiredArgsConstructor
public class SignatureService {

    private final SignatureKeyStoreService keyStoreService;

    public String sign(Ticket ticket) throws Exception {
        try {
            System.out.println("=== SignatureService.sign ===");
            System.out.println("Ticket: " + ticket);

            byte[] data = JsonCanonicalizer.canonicalize(ticket);
            System.out.println("Canonical data length: " + data.length);

            PrivateKey privateKey = keyStoreService.getPrivateKey();
            System.out.println("Private key obtained: " + (privateKey != null));

            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);
            signature.update(data);
            byte[] signed = signature.sign();
            String result = Base64.getEncoder().encodeToString(signed);
            System.out.println("Signature length: " + result.length());
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
}