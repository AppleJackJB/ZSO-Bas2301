package com.example.demo.binary;

import com.example.demo.entity.MalwareSignature;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

public final class ManifestBuilder {

    private ManifestBuilder() {
    }

    public static byte[] buildUnsigned(
            ExportType exportType,
            long generatedAtEpochMillis,
            long sinceEpochMillisOrMinusOne,
            byte[] dataSha256,
            List<MalwareSignature> records,
            int[] dataOffsets,
            int[] dataLengths,
            byte[][] recordSignatures
    ) throws IOException {
        if (dataSha256.length != 32) {
            throw new IllegalArgumentException("dataSha256 must be 32 bytes");
        }
        if (records.size() != dataOffsets.length || records.size() != dataLengths.length
                || records.size() != recordSignatures.length) {
            throw new IllegalArgumentException("parallel arrays size mismatch");
        }

        BinaryEndianWriter w = new BinaryEndianWriter();
        w.writeFixed(BinaryFormatConstants.MANIFEST_MAGIC);
        w.writeU16(BinaryFormatConstants.FORMAT_VERSION);
        w.writeU8(exportType.getCode() & 0xFF);
        w.writeI64(generatedAtEpochMillis);
        w.writeI64(sinceEpochMillisOrMinusOne);
        w.writeU32(records.size());
        w.writeFixed(dataSha256);

        for (int i = 0; i < records.size(); i++) {
            MalwareSignature s = records.get(i);
            w.writeUuid(s.getId());
            w.writeU8(ManifestStatusCode.from(s.getStatus()).getCode() & 0xFF);
            w.writeI64(s.getUpdatedAt().toEpochMilli());
            w.writeU64(dataOffsets[i]);
            w.writeU32(dataLengths[i]);
            byte[] sig = recordSignatures[i];
            w.writeU32(sig.length);
            w.writeFixed(sig);
        }
        return w.toByteArray();
    }

    public static byte[] appendManifestSignature(byte[] unsignedManifest, byte[] manifestSignature) throws IOException {
        BinaryEndianWriter w = new BinaryEndianWriter();
        w.writeFixed(unsignedManifest);
        w.writeU32(manifestSignature.length);
        w.writeFixed(manifestSignature);
        return w.toByteArray();
    }

    static byte[] decodeRecordSignature(MalwareSignature s) {
        String b64 = s.getDigitalSignatureBase64();
        if (b64 == null || b64.isBlank()) {
            return new byte[0];
        }
        return Base64.getDecoder().decode(b64);
    }
}
