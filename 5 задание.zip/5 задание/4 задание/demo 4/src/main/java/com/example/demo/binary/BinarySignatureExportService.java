package com.example.demo.binary;

import com.example.demo.entity.MalwareSignature;
import com.example.demo.entity.SignatureStatus;
import com.example.demo.repository.MalwareSignatureRepository;
import com.example.demo.service.SignatureService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.MessageDigest;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BinarySignatureExportService {

    private final MalwareSignatureRepository signatureRepository;
    private final SignatureService signatureService;

    @Transactional(readOnly = true)
    public ResponseEntity<byte[]> exportFull() throws Exception {
        List<MalwareSignature> list = new ArrayList<>(
                signatureRepository.findAllByStatus(SignatureStatus.ACTUAL));
        list.sort(Comparator.comparing(MalwareSignature::getId));
        return buildMultipart(ExportType.FULL, -1L, list);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<byte[]> exportIncrement(Instant since) throws Exception {
        List<MalwareSignature> list = new ArrayList<>(signatureRepository.findAllUpdatedAfter(since));
        list.sort(Comparator.comparing(MalwareSignature::getUpdatedAt)
                .thenComparing(MalwareSignature::getId));
        return buildMultipart(ExportType.INCREMENT, since.toEpochMilli(), list);
    }

    @Transactional(readOnly = true)
    public ResponseEntity<byte[]> exportByIds(List<UUID> ids) throws Exception {
        List<MalwareSignature> list = new ArrayList<>(signatureRepository.findAllById(ids));
        list.sort(Comparator.comparing(MalwareSignature::getId));
        return buildMultipart(ExportType.BY_IDS, -1L, list);
    }

    private ResponseEntity<byte[]> buildMultipart(
            ExportType exportType,
            long sinceEpochMillisOrMinusOne,
            List<MalwareSignature> records
    ) throws Exception {
        byte[] dataBin = DataBinBuilder.build(records);
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] dataSha256 = md.digest(dataBin);

        int n = records.size();
        int[] dataOffsets = new int[n];
        int[] dataLengths = new int[n];
        byte[][] recordSignatures = new byte[n][];

        long run = 0;
        for (int i = 0; i < n; i++) {
            MalwareSignature s = records.get(i);
            dataOffsets[i] = (int) run;
            int len = DataBinBuilder.recordPayloadLength(s);
            dataLengths[i] = len;
            run += len;
            recordSignatures[i] = ManifestBuilder.decodeRecordSignature(s);
        }

        long dataHeaderSize = BinaryFormatConstants.dataFileHeaderLength();
        if (run != (long) dataBin.length - dataHeaderSize) {
            throw new IllegalStateException("data.bin layout does not match manifest offsets");
        }

        long generatedAt = System.currentTimeMillis();
        byte[] unsignedManifest = ManifestBuilder.buildUnsigned(
                exportType,
                generatedAt,
                sinceEpochMillisOrMinusOne,
                dataSha256,
                records,
                dataOffsets,
                dataLengths,
                recordSignatures
        );
        byte[] manifestSignature = signatureService.signBinaryDocument(unsignedManifest);
        byte[] manifestBin = ManifestBuilder.appendManifestSignature(unsignedManifest, manifestSignature);

        return MultipartMixedResponseFactory.build(manifestBin, dataBin);
    }
}
