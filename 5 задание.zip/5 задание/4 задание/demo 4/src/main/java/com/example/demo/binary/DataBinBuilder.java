package com.example.demo.binary;

import com.example.demo.entity.MalwareSignature;

import java.io.IOException;
import java.util.List;

public final class DataBinBuilder {

    private DataBinBuilder() {
    }

    public static byte[] build(List<MalwareSignature> records) throws IOException {
        BinaryEndianWriter w = new BinaryEndianWriter();
        w.writeFixed(BinaryFormatConstants.DATA_MAGIC);
        w.writeU16(BinaryFormatConstants.FORMAT_VERSION);
        w.writeU32(records.size());
        for (MalwareSignature s : records) {
            w.writeUtf8WithU32Len(s.getThreatName());
            w.writeBytesWithU32Len(HexBinaryCodec.decodeHex(s.getFirstBytes()));
            w.writeBytesWithU32Len(HexBinaryCodec.decodeHex(s.getRemainderHashHex()));
            w.writeI64(s.getRemainderLength());
            w.writeUtf8WithU32Len(s.getFileType());
            w.writeI64(s.getOffsetStart());
            w.writeI64(s.getOffsetEnd());
        }
        return w.toByteArray();
    }

    public static int recordPayloadLength(MalwareSignature s) throws IOException {
        BinaryEndianWriter w = new BinaryEndianWriter();
        w.writeUtf8WithU32Len(s.getThreatName());
        w.writeBytesWithU32Len(HexBinaryCodec.decodeHex(s.getFirstBytes()));
        w.writeBytesWithU32Len(HexBinaryCodec.decodeHex(s.getRemainderHashHex()));
        w.writeI64(s.getRemainderLength());
        w.writeUtf8WithU32Len(s.getFileType());
        w.writeI64(s.getOffsetStart());
        w.writeI64(s.getOffsetEnd());
        return w.toByteArray().length;
    }
}
