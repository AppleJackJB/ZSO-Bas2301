package com.example.demo.binary;

public enum ExportType {
    FULL((byte) 0),
    INCREMENT((byte) 1),
    BY_IDS((byte) 2);

    private final byte code;

    ExportType(byte code) {
        this.code = code;
    }

    public byte getCode() {
        return code;
    }
}
