package com.example.demo.binary;

import java.util.HexFormat;

final class HexBinaryCodec {

    private HexBinaryCodec() {
    }

    static byte[] decodeHex(String hex) {
        if (hex == null || hex.isBlank()) {
            return new byte[0];
        }
        return HexFormat.of().parseHex(hex.strip());
    }
}
