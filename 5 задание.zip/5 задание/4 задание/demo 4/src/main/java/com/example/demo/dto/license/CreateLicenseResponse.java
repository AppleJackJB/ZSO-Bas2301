package com.example.demo.dto.license;

import java.util.UUID;

public class CreateLicenseResponse {
    private UUID id;
    private String code;
    private ProductInfo product;
    private OwnerInfo owner;
    private int deviceCount;
    private String description;

    // геттеры и сеттеры
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public ProductInfo getProduct() { return product; }
    public void setProduct(ProductInfo product) { this.product = product; }

    public OwnerInfo getOwner() { return owner; }
    public void setOwner(OwnerInfo owner) { this.owner = owner; }

    public int getDeviceCount() { return deviceCount; }
    public void setDeviceCount(int deviceCount) { this.deviceCount = deviceCount; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public static class ProductInfo {
        private UUID id;
        private String name;

        public UUID getId() { return id; }
        public void setId(UUID id) { this.id = id; }

        public String getName() { return name; }
        public void setName(String name) { this.name = name; }

    }

    public static class OwnerInfo {
        private Long id;

        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
    }
}