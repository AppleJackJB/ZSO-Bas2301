package com.example.demo.dto.signature;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class UpdateSignatureRequest {
    @NotBlank
    private String threatName;

    @NotBlank
    @Pattern(regexp = "^[0-9a-fA-F]+$")
    private String firstBytes;

    @NotBlank
    @Pattern(regexp = "^[0-9a-fA-F]+$")
    private String remainderHashHex;

    @Min(0)
    private Long remainderLength;

    @NotBlank
    private String fileType;

    @Min(0)
    private Long offsetStart;

    @Min(0)
    private Long offsetEnd;
}