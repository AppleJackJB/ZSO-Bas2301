package com.example.demo.dto.signature;

import com.example.demo.entity.SignatureStatus;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
public class SignatureHistoryResponse {
    private Long historyId;
    private UUID signatureId;
    private Instant versionCreatedAt;
    private String threatName;
    private String firstBytes;
    private String remainderHashHex;
    private Long remainderLength;
    private String fileType;
    private Long offsetStart;
    private Long offsetEnd;
    private Instant updatedAt;
    private SignatureStatus status;
    private String digitalSignatureBase64;
}