package com.example.demo.binary;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public final class BinaryFormatConstants {

    private static final String MANIFEST_PREFIX = "MF-";
    private static final String DATA_PREFIX = "DB-";

    public static final String STUDENT_SURNAME = "Железнов";

    public static final short FORMAT_VERSION = 1;

    public static final byte[] MANIFEST_MAGIC = buildMagic(MANIFEST_PREFIX, STUDENT_SURNAME);
    public static final byte[] DATA_MAGIC = buildMagic(DATA_PREFIX, STUDENT_SURNAME);

    private BinaryFormatConstants() {
    }

    public static int dataFileHeaderLength() {
        return DATA_MAGIC.length + 2 + 4;
    }

    private static byte[] buildMagic(String asciiPrefix, String surnameUtf8) {
        byte[] prefix = asciiPrefix.getBytes(StandardCharsets.US_ASCII);
        byte[] name = surnameUtf8.getBytes(StandardCharsets.UTF_8);
        ByteArrayOutputStream out = new ByteArrayOutputStream(prefix.length + name.length);
        out.writeBytes(prefix);
        out.writeBytes(name);
        return out.toByteArray();
    }
}
