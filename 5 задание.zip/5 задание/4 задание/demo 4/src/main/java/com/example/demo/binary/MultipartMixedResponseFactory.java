package com.example.demo.binary;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class MultipartMixedResponseFactory {

    private static final byte[] CRLF = "\r\n".getBytes(StandardCharsets.US_ASCII);

    private MultipartMixedResponseFactory() {
    }

    public static ResponseEntity<byte[]> build(byte[] manifestBin, byte[] dataBin) {
        String boundary = UUID.randomUUID().toString().replace("-", "");
        byte[] body = encodeParts(
                boundary,
                new MultipartPart("manifest.bin", manifestBin),
                new MultipartPart("data.bin", dataBin));

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType("multipart/mixed; boundary=" + boundary));

        return new ResponseEntity<>(body, headers, HttpStatus.OK);
    }

    private static byte[] encodeParts(String boundary, MultipartPart first, MultipartPart second) {
        String b = "--" + boundary;
        byte[] bBytes = b.getBytes(StandardCharsets.US_ASCII);
        byte[] end = ("--" + boundary + "--").getBytes(StandardCharsets.US_ASCII);

        byte[] firstBody = first.body();
        byte[] secondBody = second.body();

        String firstHeaders =
                "Content-Disposition: attachment; filename=\"" + first.filename() + "\"\r\n"
                        + "Content-Type: application/octet-stream\r\n"
                        + "Content-Length: " + firstBody.length + "\r\n";
        String secondHeaders =
                "Content-Disposition: attachment; filename=\"" + second.filename() + "\"\r\n"
                        + "Content-Type: application/octet-stream\r\n"
                        + "Content-Length: " + secondBody.length + "\r\n";

        byte[] fh = firstHeaders.getBytes(StandardCharsets.US_ASCII);
        byte[] sh = secondHeaders.getBytes(StandardCharsets.US_ASCII);

        int size = bBytes.length + CRLF.length + fh.length + CRLF.length + firstBody.length
                + CRLF.length + bBytes.length + CRLF.length + sh.length + CRLF.length + secondBody.length
                + CRLF.length + end.length + CRLF.length;

        byte[] out = new byte[size];
        int p = 0;
        p = writeChunk(out, p, bBytes);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, fh);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, firstBody);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, bBytes);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, sh);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, secondBody);
        p = writeChunk(out, p, CRLF);
        p = writeChunk(out, p, end);
        p = writeChunk(out, p, CRLF);
        if (p != size) {
            throw new IllegalStateException("multipart size mismatch");
        }
        return out;
    }

    private record MultipartPart(String filename, byte[] body) {
    }

    private static int writeChunk(byte[] dest, int offset, byte[] chunk) {
        System.arraycopy(chunk, 0, dest, offset, chunk.length);
        return offset + chunk.length;
    }
}
