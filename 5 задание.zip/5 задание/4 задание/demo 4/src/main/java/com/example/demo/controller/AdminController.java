package com.example.demo.controller;

import com.example.demo.entity.Product;
import com.example.demo.entity.LicenseType;
import com.example.demo.repository.ProductRepository;
import com.example.demo.repository.LicenseTypeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@RequiredArgsConstructor
public class AdminController {

    private final ProductRepository productRepository;
    private final LicenseTypeRepository licenseTypeRepository;

    @PostMapping("/product")
    public ResponseEntity<?> createProduct(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        if (name == null || name.isBlank()) {
            return ResponseEntity.badRequest().body("Product name required");
        }
        Product product = new Product();
        product.setName(name);
        productRepository.save(product);
        return ResponseEntity.status(HttpStatus.CREATED).body(product);
    }

    @PostMapping("/license-type")
    public ResponseEntity<?> createLicenseType(@RequestBody Map<String, Object> body) {
        String name = (String) body.get("name");
        Integer days = (Integer) body.get("defaultDurationInDays");
        if (name == null || days == null) {
            return ResponseEntity.badRequest().body("name and defaultDurationInDays required");
        }
        LicenseType type = new LicenseType();
        type.setName(name);
        type.setDefaultDurationInDays(days);
        licenseTypeRepository.save(type);
        return ResponseEntity.status(HttpStatus.CREATED).body(type);
    }
}