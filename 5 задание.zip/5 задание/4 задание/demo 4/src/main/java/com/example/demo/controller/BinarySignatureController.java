package com.example.demo.controller;

import com.example.demo.binary.BinarySignatureExportService;
import com.example.demo.dto.signature.IdsRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.time.format.DateTimeParseException;

@RestController
@RequestMapping("/api/binary/signatures")
@RequiredArgsConstructor
public class BinarySignatureController {

    private final BinarySignatureExportService binarySignatureExportService;

    @GetMapping("/full")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public ResponseEntity<byte[]> full() throws Exception {
        return binarySignatureExportService.exportFull();
    }

    @GetMapping("/increment")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public ResponseEntity<byte[]> increment(@RequestParam(name = "since", required = false) String sinceRaw)
            throws Exception {
        if (sinceRaw == null || sinceRaw.isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        try {
            Instant since = Instant.parse(sinceRaw.trim());
            return binarySignatureExportService.exportIncrement(since);
        } catch (DateTimeParseException ex) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PostMapping("/by-ids")
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    public ResponseEntity<byte[]> byIds(@RequestBody IdsRequest request) throws Exception {
        if (request == null || request.getIds() == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return binarySignatureExportService.exportByIds(request.getIds());
    }
}
