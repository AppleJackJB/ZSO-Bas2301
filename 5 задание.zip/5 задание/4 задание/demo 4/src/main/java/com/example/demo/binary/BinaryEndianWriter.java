package com.example.demo.binary;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class BinaryEndianWriter {

    private final ByteArrayOutputStream out = new ByteArrayOutputStream();

    public void writeU8(int value) throws IOException {
        out.write(value & 0xFF);
    }

    public void writeU16(int value) throws IOException {
        out.write((value >>> 8) & 0xFF);
        out.write(value & 0xFF);
    }

    public void writeU32(long value) throws IOException {
        if (value < 0 || value > 0xFFFFFFFFL) {
            throw new IllegalArgumentException("uint32 out of range: " + value);
        }
        out.write((int) ((value >>> 24) & 0xFF));
        out.write((int) ((value >>> 16) & 0xFF));
        out.write((int) ((value >>> 8) & 0xFF));
        out.write((int) (value & 0xFF));
    }

    public void writeU64(long value) throws IOException {
        if (value < 0) {
            throw new IllegalArgumentException("uint64 must be non-negative");
        }
        out.write((int) ((value >>> 56) & 0xFF));
        out.write((int) ((value >>> 48) & 0xFF));
        out.write((int) ((value >>> 40) & 0xFF));
        out.write((int) ((value >>> 32) & 0xFF));
        out.write((int) ((value >>> 24) & 0xFF));
        out.write((int) ((value >>> 16) & 0xFF));
        out.write((int) ((value >>> 8) & 0xFF));
        out.write((int) (value & 0xFF));
    }

    public void writeI64(long value) throws IOException {
        out.write((int) ((value >>> 56) & 0xFF));
        out.write((int) ((value >>> 48) & 0xFF));
        out.write((int) ((value >>> 40) & 0xFF));
        out.write((int) ((value >>> 32) & 0xFF));
        out.write((int) ((value >>> 24) & 0xFF));
        out.write((int) ((value >>> 16) & 0xFF));
        out.write((int) ((value >>> 8) & 0xFF));
        out.write((int) (value & 0xFF));
    }

    public void writeUuid(UUID id) throws IOException {
        ByteBuffer bb = ByteBuffer.allocate(16);
        bb.putLong(id.getMostSignificantBits());
        bb.putLong(id.getLeastSignificantBits());
        out.write(bb.array());
    }

    public void writeUtf8WithU32Len(String s) throws IOException {
        byte[] utf8 = (s == null ? "" : s).getBytes(StandardCharsets.UTF_8);
        writeU32(utf8.length);
        out.write(utf8);
    }

    public void writeBytesWithU32Len(byte[] data) throws IOException {
        byte[] b = data == null ? new byte[0] : data;
        writeU32(b.length);
        out.write(b);
    }

    public void writeFixed(byte[] data) throws IOException {
        if (data == null) {
            throw new IllegalArgumentException("data is null");
        }
        out.write(data);
    }

    public byte[] toByteArray() {
        return out.toByteArray();
    }
}
