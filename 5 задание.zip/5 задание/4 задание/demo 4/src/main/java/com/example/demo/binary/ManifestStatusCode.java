package com.example.demo.binary;

import com.example.demo.entity.SignatureStatus;

public enum ManifestStatusCode {
    ACTUAL((byte) 1),
    DELETED((byte) 2);

    private final byte code;

    ManifestStatusCode(byte code) {
        this.code = code;
    }

    public byte getCode() {
        return code;
    }

    public static ManifestStatusCode from(SignatureStatus status) {
        return switch (status) {
            case ACTUAL -> ACTUAL;
            case DELETED -> DELETED;
        };
    }
}
