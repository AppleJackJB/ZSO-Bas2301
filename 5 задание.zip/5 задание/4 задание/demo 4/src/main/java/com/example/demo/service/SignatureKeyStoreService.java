package com.example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;

@Service
public class SignatureKeyStoreService {

    private final PrivateKey privateKey;
    private final Certificate certificate;

    public SignatureKeyStoreService(
            @Value("${sign.keystore.path}") String keystorePath,
            @Value("${sign.keystore.password}") String keystorePassword,
            @Value("${sign.key.alias}") String keyAlias) throws Exception {
        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        try (var is = new ClassPathResource(keystorePath).getInputStream()) {
            keyStore.load(is, keystorePassword.toCharArray());
        }
        Key key = keyStore.getKey(keyAlias, keystorePassword.toCharArray());
        if (!(key instanceof PrivateKey)) {
            throw new IllegalStateException("Key is not a private key");
        }
        this.privateKey = (PrivateKey) key;
        this.certificate = keyStore.getCertificate(keyAlias);
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    public Certificate getCertificate() {
        return certificate;
    }
}