package com.example.demo.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.nio.charset.StandardCharsets;
import java.util.*;

public class JsonCanonicalizer {

    private static final ObjectMapper MAPPER = new ObjectMapper()
            .registerModule(new JavaTimeModule());

    public static byte[] canonicalize(Object object) throws Exception {
        JsonNode node = MAPPER.valueToTree(object);
        return toCanonical(node).getBytes(StandardCharsets.UTF_8);
    }

    private static String toCanonical(JsonNode node) {
        if (node.isObject()) {
            // Сортируем ключи
            List<String> keys = new ArrayList<>();
            node.fieldNames().forEachRemaining(keys::add);
            Collections.sort(keys);

            StringBuilder sb = new StringBuilder("{");
            for (int i = 0; i < keys.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(toJsonString(keys.get(i))).append(":").append(toCanonical(node.get(keys.get(i))));
            }
            return sb.append("}").toString();
        }

        if (node.isArray()) {
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < node.size(); i++) {
                if (i > 0) sb.append(",");
                sb.append(toCanonical(node.get(i)));
            }
            return sb.append("]").toString();
        }

        if (node.isTextual()) return toJsonString(node.asText());
        if (node.isBoolean()) return node.asBoolean() ? "true" : "false";
        if (node.isNumber()) return formatNumber(node);
        if (node.isNull()) return "null";

        throw new RuntimeException("Unknown type: " + node.getNodeType());
    }

    private static String toJsonString(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append("\"").toString();
    }

    private static String formatNumber(JsonNode node) {
        double d = node.doubleValue();
        if (Double.isNaN(d) || Double.isInfinite(d)) {
            throw new RuntimeException("NaN/Infinity not allowed");
        }
        String s = node.asText();
        return s.equals("-0") || s.equals("-0.0") ? "0" : s;
    }
}